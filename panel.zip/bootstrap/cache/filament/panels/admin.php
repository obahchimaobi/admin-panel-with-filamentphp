<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.comment-resource.pages.create-comment' => 'App\\Filament\\Resources\\CommentResource\\Pages\\CreateComment',
    'app.filament.resources.comment-resource.pages.edit-comment' => 'App\\Filament\\Resources\\CommentResource\\Pages\\EditComment',
    'app.filament.resources.comment-resource.pages.list-comments' => 'App\\Filament\\Resources\\CommentResource\\Pages\\ListComments',
    'app.filament.resources.movies-resource.pages.create-movies' => 'App\\Filament\\Resources\\MoviesResource\\Pages\\CreateMovies',
    'app.filament.resources.movies-resource.pages.edit-movies' => 'App\\Filament\\Resources\\MoviesResource\\Pages\\EditMovies',
    'app.filament.resources.movies-resource.pages.list-movies' => 'App\\Filament\\Resources\\MoviesResource\\Pages\\ListMovies',
    'app.filament.resources.movies-resource.pages.view-movies' => 'App\\Filament\\Resources\\MoviesResource\\Pages\\ViewMovies',
    'app.filament.resources.pending-movies-resource.pages.create-pending-movies' => 'App\\Filament\\Resources\\PendingMoviesResource\\Pages\\CreatePendingMovies',
    'app.filament.resources.pending-movies-resource.pages.edit-pending-movies' => 'App\\Filament\\Resources\\PendingMoviesResource\\Pages\\EditPendingMovies',
    'app.filament.resources.pending-movies-resource.pages.list-pending-movies' => 'App\\Filament\\Resources\\PendingMoviesResource\\Pages\\ListPendingMovies',
    'app.filament.resources.pending-seasons-resource.pages.create-pending-seasons' => 'App\\Filament\\Resources\\PendingSeasonsResource\\Pages\\CreatePendingSeasons',
    'app.filament.resources.pending-seasons-resource.pages.edit-pending-seasons' => 'App\\Filament\\Resources\\PendingSeasonsResource\\Pages\\EditPendingSeasons',
    'app.filament.resources.pending-seasons-resource.pages.list-pending-seasons' => 'App\\Filament\\Resources\\PendingSeasonsResource\\Pages\\ListPendingSeasons',
    'app.filament.resources.pending-series-resource.pages.create-pending-series' => 'App\\Filament\\Resources\\PendingSeriesResource\\Pages\\CreatePendingSeries',
    'app.filament.resources.pending-series-resource.pages.edit-pending-series' => 'App\\Filament\\Resources\\PendingSeriesResource\\Pages\\EditPendingSeries',
    'app.filament.resources.pending-series-resource.pages.list-pending-series' => 'App\\Filament\\Resources\\PendingSeriesResource\\Pages\\ListPendingSeries',
    'app.filament.resources.pending-series-resource.pages.view-pending-series' => 'App\\Filament\\Resources\\PendingSeriesResource\\Pages\\ViewPendingSeries',
    'app.filament.resources.seasons-resource.pages.create-seasons' => 'App\\Filament\\Resources\\SeasonsResource\\Pages\\CreateSeasons',
    'app.filament.resources.seasons-resource.pages.edit-seasons' => 'App\\Filament\\Resources\\SeasonsResource\\Pages\\EditSeasons',
    'app.filament.resources.seasons-resource.pages.list-seasons' => 'App\\Filament\\Resources\\SeasonsResource\\Pages\\ListSeasons',
    'app.filament.resources.seasons-resource.pages.view-seasons' => 'App\\Filament\\Resources\\SeasonsResource\\Pages\\ViewSeasons',
    'app.filament.resources.series-resource.pages.create-series' => 'App\\Filament\\Resources\\SeriesResource\\Pages\\CreateSeries',
    'app.filament.resources.series-resource.pages.edit-series' => 'App\\Filament\\Resources\\SeriesResource\\Pages\\EditSeries',
    'app.filament.resources.series-resource.pages.list-series' => 'App\\Filament\\Resources\\SeriesResource\\Pages\\ListSeries',
    'app.filament.resources.series-resource.pages.view-series' => 'App\\Filament\\Resources\\SeriesResource\\Pages\\ViewSeries',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.resources.user-resource.pages.view-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\ViewUser',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.latest-movies' => 'App\\Filament\\Widgets\\LatestMovies',
    'app.filament.widgets.stats-overview' => 'App\\Filament\\Widgets\\StatsOverview',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => '/home/sh3rlock/Documents/admin-panel/app/Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Resources/CommentResource.php' => 'App\\Filament\\Resources\\CommentResource',
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Resources/MoviesResource.php' => 'App\\Filament\\Resources\\MoviesResource',
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Resources/PendingMoviesResource.php' => 'App\\Filament\\Resources\\PendingMoviesResource',
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Resources/PendingSeasonsResource.php' => 'App\\Filament\\Resources\\PendingSeasonsResource',
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Resources/PendingSeriesResource.php' => 'App\\Filament\\Resources\\PendingSeriesResource',
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Resources/SeasonsResource.php' => 'App\\Filament\\Resources\\SeasonsResource',
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Resources/SeriesResource.php' => 'App\\Filament\\Resources\\SeriesResource',
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Resources/UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => '/home/sh3rlock/Documents/admin-panel/app/Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Widgets/LatestMovies.php' => 'App\\Filament\\Widgets\\LatestMovies',
    '/home/sh3rlock/Documents/admin-panel/app/Filament/Widgets/StatsOverview.php' => 'App\\Filament\\Widgets\\StatsOverview',
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => '/home/sh3rlock/Documents/admin-panel/app/Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);