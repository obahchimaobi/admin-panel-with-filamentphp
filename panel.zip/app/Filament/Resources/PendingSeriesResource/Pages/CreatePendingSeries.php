<?php

namespace App\Filament\Resources\PendingSeriesResource\Pages;

use App\Filament\Resources\PendingSeriesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePendingSeries extends CreateRecord
{
    protected static string $resource = PendingSeriesResource::class;
}
