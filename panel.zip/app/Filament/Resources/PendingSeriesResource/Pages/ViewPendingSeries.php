<?php

namespace App\Filament\Resources\PendingSeriesResource\Pages;

use App\Filament\Resources\PendingSeriesResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewPendingSeries extends ViewRecord
{
    protected static string $resource = PendingSeriesResource::class;
}
