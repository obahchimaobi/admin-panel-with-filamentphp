<?php

namespace App\Filament\Resources\PendingSeasonsResource\Pages;

use App\Filament\Resources\PendingSeasonsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePendingSeasons extends CreateRecord
{
    protected static string $resource = PendingSeasonsResource::class;
}
