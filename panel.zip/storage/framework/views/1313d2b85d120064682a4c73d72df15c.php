<div style="display: flex; align-items: center;">
    <img src="<?php echo e(asset('icons/logo.png')); ?>" alt="" style="margin-right: 10px; width: 30px">
    <span style="font-size: 20px; font-weight: bolder;">BetaMovies</span>
</div>
<?php /**PATH /home/sh3rlock/Documents/admin-panel/resources/views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>